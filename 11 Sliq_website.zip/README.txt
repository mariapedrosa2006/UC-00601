# Sliq — Website
Abra `index.html` num navegador. O site é estático e não precisa de servidor.

Funcionalidades incluídas:
- navegação por secções e design responsivo;
- apresentação do produto e quatro funções;
- quantidade + carrinho de compras;
- checkout de demonstração;
- formulário de inscrição no workshop;
- criação de conta/cartão cliente (demonstração);
- apoio, peças, Test Drive e FAQ;
- imagem de produto criada para o conceito Sliq.

Nota: pagamentos reais, base de dados, autenticação, emails e gestão real de encomendas ainda precisam de backend/serviços externos.
